const express = require('express');
const app=express();
const todos=require("./todos.json");
const fs=require('fs'); // to write new data in todos.json
app.use(express.json())// if we want to make data available and use it data to req.body ,, if it is not used than null is come
//console.log(todos);
app.get('/todos',(req,res)=>{
    res.send(todos);
})

app.post('/todos',(req,res)=>{
    const newTodoData= req.body;
    todos.push(newTodoData);
    fs.writeFileSync(__dirname+"/todos.json",JSON.stringify(todos)) // only text can be added in file thast why JSON.stringify(todos) is used
    res.send("Todo added");
})

app.listen(3000,()=>console.log(
    "http://localhost:3000"
))